# Mandiri Extreme
Sistem otomatis untuk broadcast, replikasi, evolusi, AI lokal, dan bot viewer

## Cara menjalankan
1. Jalankan init.sh untuk setup lingkungan
2. Jalankan evolve.py untuk evolusi otomatis
3. Jalankan web_ui/index.html untuk kontrol bot viewer
