def ai_response(prompt):
    return f'AI Lokal merespon: {prompt}'
