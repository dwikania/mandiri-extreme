import requests

def broadcast_message(message):
    # Fungsi untuk siaran pesan ke node lain
    print(f'Siarkan pesan: {message}')
