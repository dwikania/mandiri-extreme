import time

def evolve():
    while True:
        print('Evolusi berjalan...')
        time.sleep(5)

if __name__ == '__main__':
    evolve()
