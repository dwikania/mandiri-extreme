def propagate_message(message):
    print(f'Menyebar pesan: {message}')
