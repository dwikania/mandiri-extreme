def sync_data():
    print('Sinkronisasi data mesh')
