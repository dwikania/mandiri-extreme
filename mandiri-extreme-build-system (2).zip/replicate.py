def replicate_data(data):
    print(f'Replikasi data: {data}')
