def generate_text(seed):
    return f'Teks dari seed: {seed}'
