function startBots() {
    document.getElementById('status').innerText = 'Bot dimulai...';
    // TODO: implement API call ke backend untuk mulai bot
}
function stopBots() {
    document.getElementById('status').innerText = 'Bot dihentikan...';
    // TODO: implement API call ke backend untuk hentikan bot
}
